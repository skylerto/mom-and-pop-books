# Mom and Pop Books

# How to Use
To properly make use of this file, three steps must be taken:

- Deploy MySQL on LocalHost
- Run `setup.sql` on MySQL prior to starting application.
- Deploy the war on a tomcat server with an SSL port exposed. Due to SSL being enforced on the application, it will not run otherwise.
